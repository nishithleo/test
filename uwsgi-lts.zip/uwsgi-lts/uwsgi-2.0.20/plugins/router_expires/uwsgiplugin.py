NAME='router_expires'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['expires']
