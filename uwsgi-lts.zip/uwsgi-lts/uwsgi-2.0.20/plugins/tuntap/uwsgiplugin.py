NAME='tuntap'
CFLAGS=[]
LDFLAGS=[]
LIBS=[]
GCC_LIST=['common','firewall','tuntap']
