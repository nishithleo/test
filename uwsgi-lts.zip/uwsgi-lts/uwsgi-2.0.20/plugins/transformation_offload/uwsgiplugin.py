NAME='transformation_offload'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['offload']
